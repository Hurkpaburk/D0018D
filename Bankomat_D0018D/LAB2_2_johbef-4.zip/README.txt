*Fixed decimals!
*Fixed so the list is not shared between customers!
See comment: "Update 1, Lab2" in code!

Comments from Birgitta:

Ins�ttning ska inte g� om det inte �r r�tt kund till kontot.
Avrunda till 2 decimaler. s� ser det lite snyggare ut.
Kunderna delar kontolista vilket resulterar i att alla har tillg�ng till alla konton. Inte bra.

I �vrigt har du bra arvshantering och bra kommentering av koden.

/Birgitta
